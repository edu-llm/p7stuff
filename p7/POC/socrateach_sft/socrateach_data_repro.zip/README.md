# SocraTeach SFT data — reproduction bundle

Everything needed to regenerate, from scratch, the SFT dataset used to fine-tune
OLMo-2-1B / OLMo-2-1B-Instruct into a Socratic math tutor.

The generation is **fully deterministic** (fixed `--seed 13`), so running the
command below reproduces byte-identical splits (assuming the same upstream
Hugging Face dataset revisions).

## Contents

| File | What it is |
|------|------------|
| `prepare_socrateach_sft.py` | The one and only data-generation script. |
| `requirements.txt` | Pinned Python dependencies. |
| `REPORT.md` | Full design rationale (SI generation, co-training, filtering, sizing). |
| `system_instruction_examples.txt` | 12 sample per-dialogue System Instructions produced by the script. |

## Sources pulled at runtime (Hugging Face)

- **Pedagogical data:** `ulises-c/SocraTeach_Multi`
- **General co-training data:** `allenai/tulu-3-sft-olmo-2-mixture-0225`
  (OLMo-2's own post-training SFT mixture; specifically shard
  `data/train-00004-of-00006.parquet`)

## How to reproduce

```bash
# 1. (recommended) fresh environment
python -m venv .venv && source .venv/bin/activate

# 2. install deps
pip install -r requirements.txt

# 3. generate the data (deterministic)
python prepare_socrateach_sft.py --out_dir data --seed 13
```

Defaults: `--max_total 30000`, `--general_frac 0.25`, `--val_frac 0.05`,
`--test_frac 0.05`.

## Output (written to `data/`)

- `socrateach_sft_train.jsonl` — pedagogy (~22.5k, each with a per-dialogue
  System Instruction) + SI-free English general data (~7.5k). ~30k total.
- `socrateach_sft_val.jsonl` — pedagogy-only (held-out by problem).
- `socrateach_sft_test.jsonl` — pedagogy-only (held-out by problem).
- `system_instruction_examples.txt` — sample System Instructions.

Each line is a JSON object with a `messages` list (chat format:
`system` / `user` / `assistant`, alternating), plus metadata
(`kind` = `pedagogy` or `general`, `source`, `dialogue_id`, ...).

## What the script does (summary)

1. Downloads `SocraTeach_Multi` and flattens each dialogue into alternating
   user/assistant chat turns.
2. Builds a **per-dialogue System Instruction** grounded in the pedagogical moves
   that dialogue actually demonstrates (correction, concept explanation,
   extension vs. summary close, pacing) — assembled deterministically from
   phrasing pools keyed by a hash of the dialogue id.
3. Splits **by problem** (grouped) into train/val/test so no problem leaks
   across splits.
4. **Co-training (LearnLM-style):** mixes SI-free general data into the *train*
   split only, to prevent forgetting and define the no-System-Instruction
   behavior. General data has any `system` message stripped.
5. **English-only filtering** of general data: drops genuine foreign-language
   content (non-Latin-script ratio test + `langdetect` on prose) while keeping
   math/code/reasoning.
6. Caps train at `--max_total` with `--general_frac` general.

See `REPORT.md` for the full rationale and citations (LearnLM arXiv:2412.16429).
